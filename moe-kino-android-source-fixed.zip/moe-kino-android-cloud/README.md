# Моё кино — Android cloud build

This repository source is intended to be built with GitHub Actions. The app hosts the supplied HTML in an Android WebView and registers `moekino://import?...` deep links.

- Package: `com.moekino.app`
- Version: `1.1` (versionCode 17)
- Min Android: 7.0 (API 24)

The HTML file is in `app/src/main/assets/www/index.html`.
