package com.moekino.app

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import android.view.WindowManager
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var pendingImportUrl: String? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        webView = WebView(this)
        webView.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        setContentView(webView)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.javaScriptCanOpenWindowsAutomatically = true
        webView.settings.setSupportMultipleWindows(false)
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(NativeBridge(), "MoeKinoAndroid")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.scheme.equals("moekino", true) && uri.host.equals("import", true)) {
                    receiveImport(uri.toString())
                    return true
                }
                if (uri.scheme == "https" || uri.scheme == "http" || uri.scheme == "file") return false
                return true
            }

            @Suppress("DEPRECATION")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                val uri = Uri.parse(url)
                if (uri.scheme.equals("moekino", true) && uri.host.equals("import", true)) {
                    receiveImport(uri.toString())
                    return true
                }
                return !(uri.scheme == "https" || uri.scheme == "http" || uri.scheme == "file")
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                dispatchPendingImport()
            }
        }
        handleIntent(intent)
        webView.loadUrl("file:///android_asset/www/index.html")
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
        dispatchPendingImport()
    }

    private fun handleIntent(intent: Intent?) {
        val uri = intent?.data ?: return
        if (uri.scheme.equals("moekino", true) && uri.host.equals("import", true)) {
            pendingImportUrl = uri.toString()
        }
    }

    private fun receiveImport(url: String) {
        pendingImportUrl = url
        dispatchPendingImport()
    }

    private fun dispatchPendingImport() {
        val url = pendingImportUrl ?: return
        val quoted = JSONObject.quote(url)
        var attempts = 0
        fun tryDispatch() {
            if (isFinishing || isDestroyed) return
            webView.evaluateJavascript(
                "(function(){ if(window.MoeKinoImport && window.MoeKinoImport.handleUrl){ return window.MoeKinoImport.handleUrl($quoted); } return false; })();"
            ) { result ->
                if (result == "true") {
                    pendingImportUrl = null
                } else if (attempts++ < 12) {
                    handler.postDelayed({ tryDispatch() }, 250)
                }
            }
        }
        tryDispatch()
    }

    inner class NativeBridge {
        @JavascriptInterface
        fun ready() { runOnUiThread { dispatchPendingImport() } }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.destroy()
        }
        super.onDestroy()
    }
}
